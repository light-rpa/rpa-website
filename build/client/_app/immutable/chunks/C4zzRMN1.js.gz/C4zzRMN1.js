import{a5 as a}from"./CMwayz6E.js";a();
